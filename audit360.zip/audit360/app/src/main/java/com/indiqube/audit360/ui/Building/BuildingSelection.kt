package com.indiqube.audit360.ui.Building

import android.arch.lifecycle.ViewModelProviders
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import com.indiqube.audit360.R
import com.indiqube.audit360.databinding.ActivityBuildingSelectionBinding
import com.indiqube.audit360.injection.ViewModelFactory
import com.indiqube.audit360.ui.home.HomeViewModel

class BuildingSelection : AppCompatActivity() {

    private lateinit var binding: ActivityBuildingSelectionBinding
    private lateinit var viewModel: HomeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_building_selection)
        viewModel = ViewModelProviders.of(this, ViewModelFactory(this)).get(HomeViewModel::class.java)
        binding.model = viewModel

        val layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)



    }
}
