package com.indiqube.audit360.utils

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Observer
import android.databinding.BindingAdapter
import android.support.design.widget.TextInputLayout
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.View
import android.widget.TextView
import com.indiqube.audit360.utils.extension.getParentActivity
import com.indiqube.audit360.utils.extension.isEmailValid

@BindingAdapter("adapter")
fun setAdapter(view:RecyclerView , adapter:RecyclerView.Adapter<*>){
    view.adapter = adapter
}

@BindingAdapter("mutableVisibility")
fun setMutableVisibility(view: View, visibility:MutableLiveData<Int>? ){
    val parentActivity:AppCompatActivity? = view.getParentActivity()
    if(parentActivity!= null && visibility!= null){
        visibility.observe(parentActivity, Observer { value -> view.visibility = value?:View.VISIBLE })
    }
}

@BindingAdapter("mutableText")
fun setMutabletext(view:TextView , text:MutableLiveData<String>?){
    val parentActivity:AppCompatActivity? = view.getParentActivity()
    if(parentActivity != null && text != null) {
        text.observe(parentActivity, Observer { value -> view.text = value?:""})
    }
}
@BindingAdapter("isEmail")
fun setIsEmail(view: TextInputLayout, text: MutableLiveData<String>?) {
    val parentActivity: AppCompatActivity? = view.getParentActivity()
    if (parentActivity != null && text != null) {
        text.observe(parentActivity, Observer { value ->
            Log.d("Email", value)
            view.error = if (value!!.isEmailValid())
                null
            else
                "Invalid Email"

        })
    }
}
@BindingAdapter("isPass")
fun setIsPass(view: TextInputLayout, text: MutableLiveData<String>?) {
    val parentActivity: AppCompatActivity? = view.getParentActivity()
    if (parentActivity != null && text != null) {
        text.observe(parentActivity, Observer { value ->
            if (value!!.isNotEmpty() && value.length < 3)
                view.error = "Invalid Password"
            else
                view.error = null

        })
    }
}
